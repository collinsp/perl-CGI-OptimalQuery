#!/usr/bin/perl

use strict;
use CGI();

print CGI::header(), 
"<!DOCTYPE html>
<html>
<body>
<h1>Some Record Form</h1>
ADD SOME CODE HERE
</body>
</html>";
